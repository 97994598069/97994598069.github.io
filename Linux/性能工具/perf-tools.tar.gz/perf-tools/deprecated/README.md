Deprecated versions of tools.
