
<div class="header">
            
            <h1 class="page-title">错误页面</h1>
</div>
        
<ul class="breadcrumb">
            <li><a href="">主页</a> <span class="divider">/</span></li>
            <li class="active">权限拒绝</li><span class="divider">/</span></li>
</ul>

<div class="container-fluid">
<div class="row-fluid">    

    <div class="http-error">
        <h1>权限拒绝!</h1>
        <p class="info">您没有权限访问该页面或功能.</p>
        <p><i class="icon-home"></i></p>
        <p><a href="<?php echo site_url('index/index') ?>">返回系统首页</a></p>
    </div>


